package g

// changelog:
// 0.1 fisrt version
// 0.1.2 fix ssh error on h3c switch
// 0.2
// 0.2.1
// add write locate file
// json Unmarshal with error
// 0.2.3
const (
	VERSION = "0.2.3"
)
